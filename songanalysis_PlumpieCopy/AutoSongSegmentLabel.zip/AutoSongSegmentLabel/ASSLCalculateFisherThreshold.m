function [Threshold] = ASSLCalculateFisherThreshold(Data)

MaxValue = -10000;
Threshold = min(Data);

PlotVals = [];
for i = linspace(min(Data), max(Data), 50),
    Group1 = Data(find(Data < i));
    Group2 = Data(find(Data >= i));
    
    FisherCrit = 2*abs((mean(Group1) - mean(Group2)))/sqrt((var(Group1) + var(Group2)));
    if (FisherCrit > MaxValue)
        MaxValue = FisherCrit;
        Threshold = i;
    end
    PlotVals = [PlotVals; [i FisherCrit]];
end
%disp('Calculated threshold');
%figure;
%plot(PlotVals(:,1), PlotVals(:,2), 'ks-');