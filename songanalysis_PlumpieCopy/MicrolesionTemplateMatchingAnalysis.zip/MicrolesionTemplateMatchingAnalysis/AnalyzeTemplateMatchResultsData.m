function [Results] = AnalyzeTemplateMatchResultsData(handles)

SmoothingKernel = ones(5,1)/5;

MPH = 0;
for i = 1:handles.NoofDaysToAnalyse,
    % First analyse the output data from directed songs

    Fid = fopen(handles.DirSongFileList{i}, 'r');
    Temp = textscan(Fid, '%s', 'delimiter', '\n');
    fclose(Fid);

    SongFiles = Temp{1};

    MotifPeaks = [];
    for j = 1:length(handles.SyllTemplates.SyllableTemplates),
        SyllPeaks{j} = [];
    end
    
    for SongFileNo = 1:length(SongFiles),
        SongFile = SongFiles{SongFileNo};
        Slash = find((SongFile == '/') | (SongFile == '\'));
        if (~isempty(Slash))
            SongFile = SongFile(Slash(end)+1:end);
        end
        cd(handles.DirMotifTemplateMatchOutputFilesDir);
        Temp = load([SongFile, '.Motif.TempMatch.mat']);
        [Pks, Locs] = findpeaks(conv(Temp.Bout.MaxBoutSeqMatch, SmoothingKernel, 'same'), 'MINPEAKHEIGHT', MPH);
        Pks = Pks(:);
        Locs = Locs(:);
        
        MotifPeaks = [MotifPeaks; [Pks Temp.Bout.T(Locs)' ones(size(Pks))*SongFileNo]];
        
        cd(handles.DirSyllTemplateMatchOutputFilesDir);
        for j = 1:length(handles.SyllTemplates.SyllableTemplates),
            Temp = load([SongFile, '.', handles.SyllTemplates.SyllableTemplates{j}{1}.MotifTemplate(1).Label, '.TempMatch.mat']);
            [Pks, Locs] = findpeaks(conv(Temp.Bout.MaxBoutSeqMatch, SmoothingKernel, 'same'), 'MINPEAKHEIGHT', MPH);
            Pks = Pks(:);
            Locs = Locs(:);
        
            SyllPeaks{j} = [SyllPeaks{j}; [Pks Temp.Bout.T(Locs)' ones(size(Pks))*SongFileNo]];
        end
    end
    
    Results(i).DirSongFiles = SongFiles;
    
    Results(i).DirPeaks{1} = MotifPeaks;
    Results(i).Labels{1} = handles.MotifTemplate.MotifTemplate(1).Label;
    
    for j = 1:length(SyllPeaks),
        Results(i).DirPeaks{j+1} = SyllPeaks{j};
        Results(i).Labels{j+1} = handles.SyllTemplates.SyllableTemplates{j}{1}.MotifTemplate(1).Label;
    end
    
    % Next analyse the output data from undirected songs
    Fid = fopen(handles.UnDirSongFileList{i}, 'r');
    Temp = textscan(Fid, '%s', 'delimiter', '\n');
    fclose(Fid);

    SongFiles = Temp{1};

    MotifPeaks = [];
    for j = 1:length(handles.SyllTemplates.SyllableTemplates),
        SyllPeaks{j} = [];
    end
    
    for SongFileNo = 1:length(SongFiles),
        SongFile = SongFiles{SongFileNo};
        Slash = find((SongFile == '/') | (SongFile == '\'));
        if (~isempty(Slash))
            SongFile = SongFile(Slash(end)+1:end);
        end
        cd(handles.UnDirMotifTemplateMatchOutputFilesDir);
        Temp = load([SongFile, '.Motif.TempMatch.mat']);
        [Pks, Locs] = findpeaks(conv(Temp.Bout.MaxBoutSeqMatch, SmoothingKernel, 'same'), 'MINPEAKHEIGHT', MPH);
        Pks = Pks(:);
        Locs = Locs(:);
        
        MotifPeaks = [MotifPeaks; [Pks Temp.Bout.T(Locs)' ones(size(Pks))*SongFileNo]];
        
        cd(handles.UnDirSyllTemplateMatchOutputFilesDir);
        for j = 1:length(handles.SyllTemplates.SyllableTemplates),
            Temp = load([SongFile, '.', handles.SyllTemplates.SyllableTemplates{j}{1}.MotifTemplate(1).Label, '.TempMatch.mat']);
            [Pks, Locs] = findpeaks(conv(Temp.Bout.MaxBoutSeqMatch, SmoothingKernel, 'same'), 'MINPEAKHEIGHT', MPH);
            Pks = Pks(:);
            Locs = Locs(:);
        
            SyllPeaks{j} = [SyllPeaks{j}; [Pks Temp.Bout.T(Locs)' ones(size(Pks))*SongFileNo]];
        end
    end
    
    Results(i).UnDirSongFiles = SongFiles;
    Results(i).UnDirPeaks{1} = MotifPeaks;
    
    for j = 1:length(SyllPeaks),
        Results(i).UnDirPeaks{j+1} = SyllPeaks{j};
    end
end


    
disp('Finished analysis');