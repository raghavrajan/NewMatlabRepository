function varargout = MicroLesionMainAnalysis(varargin)
% MICROLESIONMAINANALYSIS MATLAB code for MicroLesionMainAnalysis.fig
%      MICROLESIONMAINANALYSIS, by itself, creates a new MICROLESIONMAINANALYSIS or raises the existing
%      singleton*.
%
%      H = MICROLESIONMAINANALYSIS returns the handle to a new MICROLESIONMAINANALYSIS or the handle to
%      the existing singleton*.
%
%      MICROLESIONMAINANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MICROLESIONMAINANALYSIS.M with the given input arguments.
%
%      MICROLESIONMAINANALYSIS('Property','Value',...) creates a new MICROLESIONMAINANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before MicroLesionMainAnalysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to MicroLesionMainAnalysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help MicroLesionMainAnalysis

% Last Modified by GUIDE v2.5 17-Jun-2013 13:13:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @MicroLesionMainAnalysis_OpeningFcn, ...
                   'gui_OutputFcn',  @MicroLesionMainAnalysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before MicroLesionMainAnalysis is made visible.
function MicroLesionMainAnalysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to MicroLesionMainAnalysis (see VARARGIN)

% Choose default command line output for MicroLesionMainAnalysis
handles.output = hObject;

% Initialize variable and gui data
handles.AllFileTypes = cellstr(get(handles.FileTypeMenu, 'String'));

if (~ispc)
    [status, result] = unix('whoami');
    handles.OutputDir = ['/home/', result(1:end-1), '/MicrolesionAnalysisResults/'];
    if (~exist(['/home/', result(1:end-1), '/MicrolesionAnalysisResults/'], 'dir'))
        eval(['!mkdir ''/home/' result(1:end-1) '/MicrolesionAnalysisResults''']);
    end
    set(handles.OutputDirEdit, 'String', handles.OutputDir);
end

PresentDir = pwd;

% Initialize axis to be blank without any axis
axes(handles.MLMATemplateAxis);
set(gca, 'XTick', []);
set(gca, 'YTick', []);
set(gca, 'Visible', 'off');

axes(handles.MLMASyllTemplateAxis);
set(gca, 'XTick', []);
set(gca, 'YTick', []);
set(gca, 'Visible', 'off');

axes(handles.ProgressAxis);
set(gca, 'XTick', []);
set(gca, 'YTick', []);
set(gca, 'Visible', 'off');

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes MicroLesionMainAnalysis wait for user response (see UIRESUME)
% uiwait(handles.MicroLesionAnalysisMainWindow);


% --- Outputs from this function are returned to the command line.
function varargout = MicroLesionMainAnalysis_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function BirdNameEdit_Callback(hObject, eventdata, handles)
% hObject    handle to BirdNameEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of BirdNameEdit as text
%        str2double(get(hObject,'String')) returns contents of BirdNameEdit as a double

handles.BirdName = get(hObject, 'String');
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function BirdNameEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to BirdNameEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ChooseMotifTemplateFileButton.
function ChooseMotifTemplateFileButton_Callback(hObject, eventdata, handles)
% hObject    handle to ChooseMotifTemplateFileButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[TemplateFileName, TemplateFileDir] = uigetfile('*.mat', 'Choose a template file');
handles.MotifTemplate = load(fullfile(TemplateFileDir, TemplateFileName));

ZeroStretchIndex = find(([handles.MotifTemplate.MotifTemplate.TimeStretch] == 0) & ([handles.MotifTemplate.MotifTemplate.FreqStretch] == 0));

if (~isempty(ZeroStretchIndex))
    axes(handles.MLMATemplateAxis);
    contourf(handles.MotifTemplate.MotifTemplate(ZeroStretchIndex).MotifTemplate);
    colorbar;
    set(gca, 'YTick', []);
    set(gca, 'XTick', []);
    set(handles.MotifTemplateFileNameText, 'String', TemplateFileName);
end

guidata(hObject, handles);


% --- Executes on button press in ChooseSyllTemplatesButton.
function ChooseSyllTemplatesButton_Callback(hObject, eventdata, handles)
% hObject    handle to ChooseSyllTemplatesButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

[TemplateFileName, TemplateFileDir] = uigetfile('*.mat', 'Choose a template file');
handles.SyllTemplates = load(fullfile(TemplateFileDir, TemplateFileName));

cla(handles.MLMASyllTemplateAxis);
axes(handles.MLMASyllTemplateAxis);
hold on;

Increment = 0;
for i = 1:length(handles.SyllTemplates.SyllableTemplates),
    ZeroStretchIndex = find(([handles.SyllTemplates.SyllableTemplates{i}{1}.MotifTemplate.TimeStretch] == 0) & ([handles.SyllTemplates.SyllableTemplates{i}{1}.MotifTemplate.FreqStretch] == 0));
    if (~isempty(ZeroStretchIndex))
        SyllTemplate = handles.SyllTemplates.SyllableTemplates{i}{1}.MotifTemplate(ZeroStretchIndex).MotifTemplate;
        contourf((1:1:size(SyllTemplate,2))+Increment, 1:1:size(SyllTemplate,1), SyllTemplate);
        
        SyllLabel = handles.SyllTemplates.SyllableTemplates{i}{1}.MotifTemplate(ZeroStretchIndex).Label;
        text(size(SyllTemplate,2)/2 + Increment, size(SyllTemplate,1) + 5, SyllLabel, 'FontWeight', 'bold', 'FontSize', 14);
                
        Increment = Increment + size(SyllTemplate,2) + 5;
        
        axis tight;
        set(gca, 'YTick', []);
        set(gca, 'XTick', []);
    end
end
colorbar;
axis tight;
temp = axis;
temp(4) = temp(4) + 10;
axis(temp);

set(handles.SyllTemplateFileNameText, 'String', TemplateFileName);
guidata(hObject, handles);

% --- Executes on selection change in FileTypeMenu.
function FileTypeMenu_Callback(hObject, eventdata, handles)
% hObject    handle to FileTypeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns FileTypeMenu contents as cell array
%        contents{get(hObject,'Value')} returns selected item from FileTypeMenu

handles.AllFileTypes = cellstr(get(hObject, 'String'));

if (strfind(handles.AllFileTypes{get(hObject, 'Value')}, 'Observer'))
    handles.FileType = 'obs';
else
    if (strfind(handles.AllFileTypes{get(hObject, 'Value')}, 'OKrank'))
        handles.FileType = 'okrank';
    else
        if (strfind(handles.AllFileTypes{get(hObject, 'Value')}, 'Wav'))
            handles.FileType = 'wav';
        end
    end
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function FileTypeMenu_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FileTypeMenu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function OutputDirEdit_Callback(hObject, eventdata, handles)
% hObject    handle to OutputDirEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of OutputDirEdit as text
%        str2double(get(hObject,'String')) returns contents of OutputDirEdit as a double

handles.OutputDir = get(hObject, 'String');
if (~exist(handles.OutputDir, 'dir'))
    eval(['!mkdir ''' handles.OutputDir '''']);
end

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function OutputDirEdit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to OutputDirEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in DoAnalysisButton.
function DoAnalysisButton_Callback(hObject, eventdata, handles, varargin)
% hObject    handle to DoAnalysisButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if (nargin <= 3)
    Temp = inputdlg('How many days do you want to analyse', 'No of days');
    handles.NoofDaysToAnalyse = str2double(Temp{1});

    FileSep = filesep;

    for i = 1:handles.NoofDaysToAnalyse,
        handles.DataDirectories{i} = uigetdir(pwd, ['Pick data directory for day #', num2str(i)]);

        [FileName, PathName] = uigetfile('*', ['Pick a filelist for all the directed songs for day #', num2str(i)]);
        handles.DirSongFileList{i} = [PathName, FileName];

        [FileName, PathName] = uigetfile('*', ['Pick a filelist for all the undirected songs for day #', num2str(i)]);
        handles.UnDirSongFileList{i} = [PathName, FileName];
    end
else
    handles.NoofDaysToAnalyse = varargin{1};
    handles.DataDirectories = varargin{2};
    handles.DirSongFileList{i} = varargin{3};
    handles.UnDirSongFileList{i} = varargin{4};
end
FileSep = filesep;
if (handles.OutputDir(end) ~= FileSep)
    handles.OutputDir(end+1) = FileSep;
end

% Make directories for storing template match files
% First for motif template matches
MotifTemplateMatchOutputFilesDir = [handles.OutputDir, get(handles.MotifTemplateFileNameText, 'String'), '.TemplateMatchResults', FileSep];
eval(['!mkdir ''' MotifTemplateMatchOutputFilesDir '''']);

DirMotifTemplateMatchOutputFilesDir = [handles.OutputDir, get(handles.MotifTemplateFileNameText, 'String'), '.TemplateMatchResults', FileSep, 'Dir', FileSep];
eval(['!mkdir ''' DirMotifTemplateMatchOutputFilesDir '''']);

UnDirMotifTemplateMatchOutputFilesDir = [handles.OutputDir, get(handles.MotifTemplateFileNameText, 'String'), '.TemplateMatchResults', FileSep, 'UnDir', FileSep];
eval(['!mkdir ''' UnDirMotifTemplateMatchOutputFilesDir '''']);

% Next for syllable template matches
SyllTemplateMatchOutputFilesDir = [handles.OutputDir, get(handles.SyllTemplateFileNameText, 'String'), '.TemplateMatchResults', FileSep];
eval(['!mkdir ''' SyllTemplateMatchOutputFilesDir '''']);

DirSyllTemplateMatchOutputFilesDir = [handles.OutputDir, get(handles.SyllTemplateFileNameText, 'String'), '.TemplateMatchResults', FileSep, 'Dir', FileSep];
eval(['!mkdir ''' DirSyllTemplateMatchOutputFilesDir '''']);

UnDirSyllTemplateMatchOutputFilesDir = [handles.OutputDir, get(handles.SyllTemplateFileNameText, 'String'), '.TemplateMatchResults', FileSep, 'UnDir', FileSep];
eval(['!mkdir ''' UnDirSyllTemplateMatchOutputFilesDir '''']);

for i = 1:handles.NoofDaysToAnalyse,
    TemplateMatch(handles.DataDirectories{i}, handles.DirSongFileList{i}, handles.FileType, handles.MotifTemplate, 'Motif', DirMotifTemplateMatchOutputFilesDir, handles.ProgressText, handles.ProgressAxis, ['Day #', num2str(i), ' Dir: '], 'r');
    TemplateMatch(handles.DataDirectories{i}, handles.UnDirSongFileList{i}, handles.FileType, handles.MotifTemplate, 'Motif', UnDirMotifTemplateMatchOutputFilesDir, handles.ProgressText, handles.ProgressAxis, ['Day #', num2str(i), ' UnDir: '], 'b');
    
    for j = 1:length(handles.SyllTemplates.SyllableTemplates),
        NoofTemplates = length(handles.SyllTemplates.SyllableTemplates{j});
        TemplateChoice = min(NoofTemplates, 2);
        TemplateMatch(handles.DataDirectories{i}, handles.DirSongFileList{i}, handles.FileType, handles.SyllTemplates.SyllableTemplates{j}{TemplateChoice}, handles.SyllTemplates.SyllableTemplates{j}{TemplateChoice}.MotifTemplate(1).Label, DirSyllTemplateMatchOutputFilesDir, handles.ProgressText, handles.ProgressAxis, ['Day #', num2str(i), ' Dir: '], 'r');
        TemplateMatch(handles.DataDirectories{i}, handles.UnDirSongFileList{i}, handles.FileType, handles.SyllTemplates.SyllableTemplates{j}{TemplateChoice}, handles.SyllTemplates.SyllableTemplates{j}{TemplateChoice}.MotifTemplate(1).Label, UnDirSyllTemplateMatchOutputFilesDir, handles.ProgressText, handles.ProgressAxis, ['Day #', num2str(i), ' UnDir: '], 'b');
    end
end

handles.DirMotifTemplateMatchOutputFilesDir = DirMotifTemplateMatchOutputFilesDir;
handles.UnDirMotifTemplateMatchOutputFilesDir = UnDirMotifTemplateMatchOutputFilesDir;

handles.DirSyllTemplateMatchOutputFilesDir = DirSyllTemplateMatchOutputFilesDir;
handles.UnDirSyllTemplateMatchOutputFilesDir = UnDirSyllTemplateMatchOutputFilesDir;

guidata(hObject, handles);
disp('Finished Analysis');


% --- Executes on button press in ResultsButton.
function ResultsButton_Callback(hObject, eventdata, handles)
% hObject    handle to ResultsButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

MicroLesionResultsAnalysis(handles);


% --- Executes on button press in SaveDataButton.
function SaveDataButton_Callback(hObject, eventdata, handles)
% hObject    handle to SaveDataButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in DoTemplateSelectivityAnalysis.
function DoTemplateSelectivityAnalysis_Callback(hObject, eventdata, handles)
% hObject    handle to DoTemplateSelectivityAnalysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

DoAnalysisButton_Callback(hObject, eventdata, handles, 'Selectivity');

% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
