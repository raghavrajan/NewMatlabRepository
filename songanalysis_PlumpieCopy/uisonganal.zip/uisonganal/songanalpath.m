addpath /net/django/bdwright/work/zfinch/song_anal/uisonganal
addpath /net/django/bdwright/work/zfinch/song_anal/uisonganal/spect

