function [ValidBoutIndices] = INAFindValidBouts(Onsets, Offsets, BoutIndices, MotifIndices)

ValidBoutIndices = [];

disp('Finished finding valid bouts');